# Checkups => Milestones

For customers, we're renaming "Checkups" to "Milestones". For sanity's sake, everything
in the code is called Checkups; no combining.
